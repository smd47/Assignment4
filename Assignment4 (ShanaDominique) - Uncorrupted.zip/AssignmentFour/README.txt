Installation:

1. (if from github) clone repository
2. use env with Django and necessary packages
   - to create a new environment run `conda create --name <envname> --file requirements.txt`
   - activate the environment `conda activate <envname>`
3. `python manage.py runserver`