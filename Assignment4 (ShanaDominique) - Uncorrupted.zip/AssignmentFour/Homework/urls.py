from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns  = [
    path('', views.index, name='index'),
    path('cart/', views.cart, name='cart'),
]

#my home page was having an issue, had to add STATIC_ROOT to ensure Django
#looks for the file in the static folder
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)