document.addEventListener("DOMContentLoaded", function() {
    const button = document.getElementById('button');
    const itemCount = document.getElementById('itemCount');
    const displayString = document.getElementById('displayString');
    const reversedString = document.getElementById('reversedString');
    const vowelCount = document.getElementById('vowelCt');
    const consonantCount = document.getElementById('consonantCt');

    // Retrieve string from file located in the static folder
    fetch('/static/file.txt')
        .then(function(response) {
            return response.text();
        })
        .then(function(data) {
            displayString.textContent = data;
            updateItemCount(data);
            reversedString.textContent = reverseString(data);
            vowelCount.textContent = countVowels(data);
            consonantCount.textContent = countConsonants(data);
        })
        .catch(function(error) {
            console.error('Error fetching string:', error);
        });

    // Function to reverse a string
    function reverseString(str) {
        return str.split("").reverse().join("");
    }

    // Function to count vowels in a string
    function countVowels(str) {
        return str.toLowerCase().split("").filter(function(char) {
            return "aeiou".includes(char);
        }).length;
    }

    // Function to count consonants in a string
    function countConsonants(str) {
        return str.toLowerCase().split("").filter(function(char) {
            return "bcdfghjklmnpqrstvwxyz".includes(char);
        }).length;
    }

    // Updates cart item count
    function updateItemCount(string) {
        itemCount.textContent = string.length;
    }

    // Cart button click event
    button.addEventListener('click', function() {
        window.location.href = 'cart.html';
    });
});